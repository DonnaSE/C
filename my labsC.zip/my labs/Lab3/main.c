#include <stdio.h>
#include <string.h>
// put the prototype for the functions before main function
void printRecord(char first[][21], char last[][21], double score[], int size);
void searchFirst(char first[][21], char last[][21], double score[], int size);
void searchLast(char first[][21], char last[][21], double score[], int size);
void sortScoar(char first[][21], char last[][21], double score[], int size);
void sortLastName(char first[][21], char last[][21], double score[], int size);
void MaxScore(char first[][21], char last[][21], double score[], int size);
void MinScore(char first[][21], char last[][21], double score[], int size);
int main()
{
    int size, i, choose;
    printf("Please indicate number of records you want to enter(min 5, max 15):\n");
    // get the size of the array from the user which is the number of records
    scanf(" %d",&size);
    printf("Please input records of students (enter a new line after each input)");
    printf(", with following format first name last name score\n");
    char first[size][21];
    char last[size][21];
    double score[size];
    //get input from the user for first and last name and score of each student
    for(i=0; i<size; i++)
    {
        printf("Enter the first name of student %d:\n",(i+1));
        scanf(" %s", &first[i]);
        printf("Enter the last name of student %d:\n",(i+1));
        scanf(" %s",&last[i]);
        printf("Enter the score of student %d:\n",(i+1));
        scanf("%lf", &score[i]);
    }
    // loop for the menu that the user will choose from
    int stop =1;
    while(stop)// condition to stop the loop
    {
        printf("\n\nChoose number from this menu:\n");
        printf("*******************************\n");
        printf("Print records (press 1)\n");
        printf("Search by first name (press 2)\n");
        printf("Search by last name (press 3)\n");
        printf("Sort by score (press 4)\n");
        printf("Sort by last name (press 5)\n");
        printf("Find Max Score (press 6)\n");
        printf("Find Min Score (press 7)\n");
        printf("Exit the program (press 0)\n");
        scanf(" %d",&choose);
        if(choose == 1)
            printRecord(first, last, score, size);
        else if(choose == 2)
            searchFirst(first, last, score, size);
        else if(choose == 3)
            searchLast(first, last, score, size);
        else if(choose == 4)
            sortScoar(first, last, score, size);
        else if(choose == 5)
            sortLastName(first, last, score, size);
        else if(choose == 6)
            MaxScore(first, last, score, size);
        else if(choose == 7)
            MinScore(first, last, score, size);
        else if(choose == 0) // when the user enter 0 the program will stop
        {
            printf("***Nice to meet you***\n\n");
            stop=0;
        }
        else // if the input does not match with the list
            printf("Sorry that is not in this menu");
    }
    return 0;
}
// this function is for printing all student and their grades
void printRecord(char first[][21], char last[][21], double score[], int size)
{
    int i;
    printf("\n");
    for(i=0; i<size; i++)
        printf("First Name: %s, Last Name: %s, Score: %.2lf\n",first[i],last[i],score[i]);
}
//using this function to search for student by his first name and then print his information
void searchFirst(char first[][21], char last[][21], double score[], int size)
{
    int i;
    char targetName[21];
    printf("What is the first name of the student that you looking for? \n");
    scanf(" %s",&targetName);
    for(i=0; i<size; i++)
    {
        if (strcmp(targetName,first[i])==0)//==first[i])
            printf("\n%s %s %.2lf\n",first[i], last[i],score[i]);
    }
}
//using this function to search for student by his last name and then print his information
void searchLast(char first[][21], char last[][21], double score[], int size)
{
    int i;
    char targetName[21];
    printf("What is the last name of the student that you looking for? \n");
    scanf(" %s",&targetName);
    for(i=0; i<size; i++)
    {
        if (strcmp(targetName,last[i])==0)//==first[i])
            printf("\n%s %s %.2lf\n",first[i], last[i],score[i]);
    }
}
//function to sort the student based on their score
void sortScoar(char first[][21], char last[][21], double score[], int size)
{
    int i, j, temp=-1;
    char tempFirst[21];
    char tempLast[21];
    for(i=0; i<size-1; i++)
        for(j=0; j<size-1-i; j++)
        {
            if(score[j]>score[j+1]) //based on this condition it going to sort the score
            {
                temp=score[j];
                score[j]=score[j+1];
                score[j+1]=temp;
                // strcpy is to replace the string
                strcpy(tempFirst,first[j]); // replace tempFirst by first[j]
                strcpy(first[j],first[j+1]); // replace first[j] by first[j+1]
                strcpy(first[j+1],tempFirst);  // replace first[j] by tempFirst
                // doing same thing with the last name
                strcpy(tempLast,last[j]);
                strcpy(last[j],last[j+1]);
                strcpy(last[j+1],tempLast);
            }
        }
    for(i=0; i<size; i++)
        printf("First Name: %s, Last Name: %s, Score: %.2lf\n",first[i],last[i],score[i]);
}
// function to sort the student by the last name
void sortLastName(char first[][21], char last[][21], double score[], int size)
{
    int i, j, temp=-1;
    char tempFirst[21];
    char tempLast[21];
    for(i=0; i<size-1; i++)
        for(j=0; j<size-1-i; j++)
        {
            if(strcmp(last[j],last[j+1])>0)
            {
                temp=score[j];
                score[j]=score[j+1];
                score[j+1]=temp;
                // strcpy is to replace the string
                strcpy(tempFirst,first[j]); // replace tempFirst by first[j]
                strcpy(first[j],first[j+1]); // replace first[j] by first[j+1]
                strcpy(first[j+1],tempFirst);  // replace first[j] by tempFirst
                // doing same thing with the last name
                strcpy(tempLast,last[j]);
                strcpy(last[j],last[j+1]);
                strcpy(last[j+1],tempLast);
            }
        }
    for(i=0; i<size; i++)
        printf("First Name: %s, Last Name: %s, Score: %.2lf \n",first[i],last[i],score[i]);
}
// function to find maximum score and print the name of the student and his score
void MaxScore(char first[][21], char last[][21], double score[], int size)
{
    int i;
    double max=score[0];
    for(i=0; i<size; i++)
        if(max < score[i])
            max=score[i];

    for(i=0; i<size; i++)
        if(score[i]==max)
            printf("The maximum score is for %s %s which is %.2lf\n",first[i],last[i],max);
}
// function to find minimum score and print the name of the student and his score
void MinScore(char first[][21], char last[][21], double score[], int size)
{
    int i;
    double min=score[0];
    for(i=0; i<size; i++)
        if(min > score[i])
            min=score[i];

    for(i=0; i<size; i++)
        if(score[i]==min)
            printf("The minimum score is for %s %s which is %.2lf\n",first[i],last[i],min);
}
